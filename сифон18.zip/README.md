# iPhone 18 Pro Max: concept page

A static, dependency-free mock-up (HTML + CSS + vanilla JS). **The iPhone 18 Pro Max is fictional and this is not an official Apple page.**

## Run
Open `index.html` in a modern browser (keep `assets/` next to it). No build step.
No folders handy? Open `standalone.html`: the same page in one file, with the photo embedded.

## Structure
- `index.html`: nav, hero (photo + details), highlights, footer; ARIA listbox over the photo
- `style.css`: tokens (`--theme-color`), layout, transitions, mobile stacking, reduced motion
- `script.js`: intro sequence, hover/select state, keyboard support, price updates
- `assets/iphone-18-pro-max.jpg`: the supplied reference photo, used unchanged

## How the photo works
The photo is one image. Four transparent hit areas (`<li class="phone">`) sit over the four phones; their position is set by `--l` (left) and `--w` (width) in percent, and `data-cx` is the phone's center used for the zoom. If you swap the photo, adjust those three values per phone.

## Customize
- **Colors:** `data-name` and `data-bg` (page tint) on each `<li class="phone">`; keep dark text readable on the tint.
- **Prices:** `data-price` on each storage radio, or replace `currentPrice()` in `script.js` with a value from your pricing API.
- **Specs / copy:** edit the `<dl class="specs">` block and the highlight cards.

## Pricing & content notes
Prices are illustrative placeholders. 256 GB = 3879.99 ₼ and 512 GB = 4399.99 ₼ follow example listings seen on bakuelectronics.az; 128 GB and 1 TB are invented. Verify real prices at the retailer. The photo is a concept render supplied by the site owner and shows Apple branding: credit the original source and confirm usage rights before publishing.

## Record a demo GIF
Use LiceCap, ScreenToGif or Kap for ~8 seconds: let the intro play, hover each phone, click one, change storage, click it again to deselect.

## Test checklist
Hover zooms toward the phone, dims the others and tints the page, then reverts on mouse-out; click persists, click again clears; Tab, arrows, Enter/Space work and `aria-selected` updates; storage changes the price; layout stacks on small screens; text stays readable on every tint; only `transform`/`opacity` animate (plus the page background color).
